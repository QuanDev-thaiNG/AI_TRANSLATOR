# English Chat Tutor

> **Application:** AI English Conversation Practice  
> **Stack:** Python + Flask (backend), Gemini API (LLM), frontend HTML/CSS/JS, extension: Text-to-Speech (TTS) for speaking practice  
> **Goal:** Users enter questions or short conversations → AI responds in **English**, with **Vietnamese translation** and **grammar analysis**; option for speaking practice (text → speech).

## Overview

English Chat Tutor is a web application that helps users practice English conversation. When a user sends a question or short conversation, the backend calls the Gemini API (or equivalent LLM model) to generate a response in English, along with a Vietnamese translation and grammar analysis (sentence structure, vocabulary, areas for improvement). If speaking practice mode is enabled, the system outputs audio from the English response (TTS).

## Features

- Simple, responsive interface for conversation.
- Responses in English.
- Includes **Vietnamese translation**.
- Includes **grammar analysis** (brief section: structure, grammar points to note, alternative vocabulary).
- Saves conversation history (session/localStorage).
- **Speaking practice mode**: pronounces responses using TTS.
- Supports Copilot / ChatGPT prompt to automatically generate project code.

## Architecture & Data Flow

1. Frontend (HTML/JS) sends POST `/api/chat` with payload `{ "prompt": "...", "mode": "talk"|"practice" }`.
2. Flask backend validates, normalizes the prompt, calls Gemini API for a response.
3. Backend parses the response into: `answer_en`, `translation_vi`, `grammar_notes`.
4. If `mode === "talk"` or user enables TTS, backend (or frontend) calls TTS service to create audio file (mp3/ogg) and returns URL.
5. Frontend displays results and plays audio if available.

## Requirements

- Python 3.10+
- Flask
- `requests`
- Gemini API access (API key)
- (Optional) gTTS / pyttsx3 / Google Cloud TTS / ElevenLabs SDK for TTS

## Installation & Setup

1. Clone the repository:
   ```bash
   git clone <repo-url>
   cd english-chat-tutor
   ```

2. Create a virtual environment and install dependencies:
   ```bash
   # On Windows
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   
   # On macOS/Linux
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. Create a `.env` file based on `.env.example` and add your Gemini API key:
   ```
   FLASK_APP=app.py
   FLASK_ENV=development
   PORT=5000
   GEMINI_API_KEY=your_gemini_api_key_here
   ```

4. Run the application:
   ```bash
   # On Windows
   run.bat
   
   # On macOS/Linux
   ./run.sh
   ```

5. Open your browser and navigate to `http://localhost:5000`

## API Endpoints

### `POST /api/chat`
- Description: Send a prompt and receive a response.
- Request body (JSON):
  ```json
  {
    "prompt": "Hi, can you help me practice greetings?",
    "mode": "practice",   // "practice" | "talk"
    "tts": false,         // whether to enable TTS
    "language": "en"      // target language (default en)
  }
  ```
- Response (JSON):
  ```json
  {
    "answer_en": "Sure — let's practice greetings. ...",
    "translation_vi": "Chắc chắn — chúng ta hãy luyện chào hỏi. ...",
    "grammar_notes": {
      "summary": "Using present simple for habits...",
      "issues": [
        {
          "text": "I going to store",
          "correction": "I'm going to store",
          "explanation": "Missing 'be' in present continuous."
        }
      ],
      "vocabulary_suggestions": ["hello", "hi", "good morning"]
    },
    "audio_url": "/api/audio/uuid.mp3" // if tts=true
  }
  ```

### `GET /api/history`
- Description: Get session history.

### `POST /api/tts`
- Description: Generate audio from text.
- Request:
  ```json
  { "text": "Hello! How are you?", "voice": "en-US-Wavenet-A" }
  ```
- Response: `{ "audio_url": "/audio/..." }`

## Text-to-Speech Integration

The application supports multiple TTS options:

- **Client-side TTS**: Uses Web Speech API (`speechSynthesis`) — simple but voice quality depends on the browser.
- **Server-side / high quality**:
  - Google Cloud Text-to-Speech (WaveNet) — requires key and billing.
  - gTTS (free, limited): Python `gtts` to generate mp3.
  - `pyttsx3` for offline use, but limited voice quality.

## Development

### Project Structure
```
english-chat-tutor/
├─ app.py                # Main Flask application
├─ requirements.txt      # Python dependencies
├─ run.sh               # Setup and run script (Unix)
├─ run.bat              # Setup and run script (Windows)
├─ .env.example         # Environment variables template
├─ README.md            # This file
├─ templates/
│  └─ index.html        # Main HTML template
├─ static/
│  ├─ styles.css        # CSS styles
│  └─ audio/            # Generated audio files
├─ modules/
│  ├─ llm_provider.py   # LLM integration
│  └─ tts_provider.py   # TTS functionality
└─ tests/
   └─ test_api.py       # API tests
```

### Testing

Run tests with pytest:
```bash
python -m pytest tests/
```

## Deployment

- **Local:** `flask run` or `gunicorn app:app`
- **Cloud (suggestions):** Render, Fly.io, Heroku (Python buildpack), Google Cloud Run.
- **CORS & HTTPS:** Enable CORS for frontend if on separate domain; always use HTTPS when calling third-party APIs.

## Security Notes

- **Never** store API keys in the repository. Use environment variables / secret manager.
- If storing conversation history on the server: comply with GDPR/PDPA if applicable — notify users.
- Limit prompt size and request frequency to prevent abuse.
- Filter input to prevent prompt injection: sanitize input, add clear system prompts.

## License

MIT License

---

## Getting Started

1. Get a Gemini API key from [Google AI Studio](https://makersuite.google.com/app/apikey).
2. Set up the project following the installation instructions above.
3. Start the application and open it in your browser.
4. Enter an English phrase or question in the text area and click "Send".
5. The AI will respond with an English answer, Vietnamese translation, and grammar analysis.
6. Enable the "Speaking practice" checkbox to hear the AI's response spoken aloud.

## Troubleshooting

- If you encounter issues with the Gemini API, check your API key and ensure you have sufficient quota.
- For TTS issues, try installing additional TTS libraries or switch to client-side TTS.
- If the application fails to start, check the console for error messages and ensure all dependencies are installed.