import os
import sys
import json
import unittest
from unittest.mock import patch, MagicMock

# Add parent directory to path to import app
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import app
from modules.llm_provider import GeminiProvider


class TestAPI(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
    
    def test_index_route(self):
        """Test that the index route returns the main page"""
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'English Chat Tutor', response.data)
    
    def test_missing_prompt(self):
        """Test that the API returns an error when prompt is missing"""
        response = self.app.post('/api/chat', 
                               json={},
                               content_type='application/json')
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_empty_prompt(self):
        """Test that the API returns an error when prompt is empty"""
        response = self.app.post('/api/chat', 
                               json={'prompt': ''},
                               content_type='application/json')
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    @patch('app.send_prompt_to_gemini')
    def test_chat_endpoint(self, mock_send_prompt):
        """Test that the chat endpoint returns the expected response"""
        # Mock the response from the LLM
        mock_response = {
            "answer_en": "This is a test response.",
            "translation_vi": "Đây là câu trả lời kiểm tra.",
            "grammar_notes": {
                "summary": "No grammar issues found.",
                "issues": [],
                "vocabulary_suggestions": ["test", "example"]
            }
        }
        mock_send_prompt.return_value = mock_response
        
        # Make the request
        response = self.app.post('/api/chat',
                               json={'prompt': 'Test prompt', 'tts': False},
                               content_type='application/json')
        
        # Check the response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['answer_en'], mock_response['answer_en'])
        self.assertEqual(data['translation_vi'], mock_response['translation_vi'])
        self.assertEqual(data['grammar_notes'], mock_response['grammar_notes'])
    
    @patch('app.text_to_speech_save')
    @patch('app.send_prompt_to_gemini')
    def test_chat_with_tts(self, mock_send_prompt, mock_tts):
        """Test that the chat endpoint generates TTS when requested"""
        # Mock the response from the LLM
        mock_response = {
            "answer_en": "This is a test response.",
            "translation_vi": "Đây là câu trả lời kiểm tra.",
            "grammar_notes": {
                "summary": "No grammar issues found.",
                "issues": [],
                "vocabulary_suggestions": ["test", "example"]
            }
        }
        mock_send_prompt.return_value = mock_response
        
        # Mock the TTS function
        mock_tts.return_value = True
        
        # Make the request
        response = self.app.post('/api/chat',
                               json={'prompt': 'Test prompt', 'tts': True},
                               content_type='application/json')
        
        # Check the response
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('audio_url', data)
        self.assertTrue(mock_tts.called)


class TestLLMProvider(unittest.TestCase):
    @patch('modules.llm_provider.requests.post')
    def test_send_prompt(self, mock_post):
        """Test that the LLM provider correctly processes responses"""
        # Mock the response from the API
        mock_response = MagicMock()
        mock_response.json.return_value = {
            'candidates': [{
                'content': {
                    'parts': [{
                        'text': json.dumps({
                            "answer_en": "Test answer",
                            "translation_vi": "Câu trả lời kiểm tra",
                            "grammar_notes": {
                                "summary": "Test summary",
                                "issues": [],
                                "vocabulary_suggestions": []
                            }
                        })
                    }]
                }
            }]
        }
        mock_post.return_value = mock_response
        
        # Create provider with mock API key
        provider = GeminiProvider(api_key='test_key')
        
        # Call the method
        result = provider.send_prompt('Test prompt')
        
        # Check the result
        self.assertEqual(result['answer_en'], 'Test answer')
        self.assertEqual(result['translation_vi'], 'Câu trả lời kiểm tra')
        self.assertEqual(result['grammar_notes']['summary'], 'Test summary')


if __name__ == '__main__':
    unittest.main()