import os
import json
import uuid
import logging
from flask import Flask, request, jsonify, render_template, send_from_directory
from dotenv import load_dotenv
import requests
from modules.tts_provider import text_to_speech_save

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.DEBUG if os.getenv('FLASK_ENV') == 'development' else logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)

# Configuration
# Try to load API key from .env file directly
GEMINI_API_KEY = None
with open(os.path.join(os.path.dirname(__file__), '.env'), 'r') as f:
    for line in f:
        if line.startswith('GEMINI_API_KEY='):
            GEMINI_API_KEY = line.strip().split('=', 1)[1]
            break

if GEMINI_API_KEY is None:
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')

print(f"API Key: {GEMINI_API_KEY}")
AUDIO_TMP_DIR = os.getenv('AUDIO_TMP_DIR', os.path.join(os.path.dirname(__file__), 'static', 'audio'))

# Ensure audio directory exists
os.makedirs(AUDIO_TMP_DIR, exist_ok=True)

# System prompt for Gemini API
SYSTEM_PROMPT = """
You are an English language tutor helping non-native speakers practice English conversation.
For each user message, provide:
1. A natural, helpful response in English (answer_en)
2. A Vietnamese translation of your response (translation_vi)
3. A Simplified Chinese translation of your response with Pinyin (translation_zh)
4. Grammar analysis of any errors or improvements in the user's message (grammar_notes)

Your response MUST be in the following JSON format:
{
  "answer_en": "Your English response here",
  "translation_vi": "Vietnamese translation of your response",
  "translation_zh": "简体中文翻译 (pīnyīn)",
  "grammar_notes": {
    "summary": "Brief summary of grammar points",
    "issues": [
      {
        "text": "Problematic text from user",
        "correction": "Corrected version",
        "explanation": "Explanation of the grammar rule"
      }
    ],
    "vocabulary_suggestions": ["alternative1", "alternative2"]
  }
}
"""


def send_prompt_to_gemini(prompt: str) -> dict:
    """
    Send prompt to Gemini API and return structured response
    """
    if not GEMINI_API_KEY:
        logger.error("GEMINI_API_KEY not set in environment variables")
        raise ValueError("GEMINI_API_KEY not configured")
    
    try:
        # Gemini API endpoint
        url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
        
        # Prepare request payload
        payload = {
            "contents": [
                {
                    "parts": [{"text": SYSTEM_PROMPT + "\n\nUser message: " + prompt}]
                }
            ],
            "generationConfig": {
                "temperature": 0.7,
                "topK": 40,
                "topP": 0.95,
                "maxOutputTokens": 1024
            }
        }
        
        # Send request to Gemini API
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": GEMINI_API_KEY
        }
        
        response = requests.post(url, headers=headers, json=payload)
        
        # Print response for debugging
        print("Response status code:", response.status_code)
        print("Response content:", response.text)
        
        response.raise_for_status()  # Raise exception for HTTP errors
        
        # Parse response
        result = response.json()
        
        # Extract text from response
        response_text = result.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '')
        
        # Clean up response text - remove markdown code blocks if present
        if response_text.startswith('```json'):
            response_text = response_text.replace('```json\n', '', 1)
            if response_text.endswith('```\n'):
                response_text = response_text[:-4]
            elif response_text.endswith('```'):
                response_text = response_text[:-3]
        
        # Parse JSON from response text
        try:
            response_data = json.loads(response_text)
            # Validate response structure
            required_fields = ['answer_en', 'translation_vi', 'translation_zh', 'grammar_notes']
            for field in required_fields:
                if field not in response_data:
                    logger.warning(f"Field {field} missing in Gemini response")
                    response_data[field] = "" if field != "grammar_notes" else {"summary": "", "issues": [], "vocabulary_suggestions": []}
            
            # Ensure grammar_notes has the correct structure
            if 'grammar_notes' in response_data and isinstance(response_data['grammar_notes'], dict):
                grammar_fields = ['summary', 'issues', 'vocabulary_suggestions']
                for field in grammar_fields:
                    if field not in response_data['grammar_notes']:
                        response_data['grammar_notes'][field] = [] if field != "summary" else ""
            
            return response_data
        except json.JSONDecodeError:
            logger.error(f"Failed to parse JSON from Gemini response: {response_text}")
            # Fallback response if JSON parsing fails
            return {
                "answer_en": "I'm sorry, I couldn't process your request properly. Could you try again?",
                "translation_vi": "Xin lỗi, tôi không thể xử lý yêu cầu của bạn đúng cách. Bạn có thể thử lại không?",
                "grammar_notes": {
                    "summary": "",
                    "issues": [],
                    "vocabulary_suggestions": []
                }
            }
    
    except requests.exceptions.RequestException as e:
        logger.error(f"Error calling Gemini API: {str(e)}")
        raise


@app.route('/')
def index():
    """
    Render the main page
    """
    return render_template('index.html')


@app.route('/api/chat', methods=['POST'])
def chat():
    """
    Process chat request and return AI response
    """
    try:
        # Get request data
        data = request.json
        if not data or 'prompt' not in data:
            return jsonify({"error": "Missing 'prompt' in request"}), 400
        
        prompt = data.get('prompt', '').strip()
        mode = data.get('mode', 'practice')  # 'practice' or 'talk'
        tts_enabled = data.get('tts', False)  # Whether to generate audio
        
        # Validate prompt
        if not prompt:
            return jsonify({"error": "Empty prompt"}), 400
        
        # Get response from Gemini
        response_data = send_prompt_to_gemini(prompt)
        
        # Generate audio if TTS is enabled
        if tts_enabled or mode == 'talk':
            try:
                # Generate a unique filename
                audio_filename = f"{uuid.uuid4()}.mp3"
                audio_path = os.path.join(AUDIO_TMP_DIR, audio_filename)
                
                # Generate audio file
                text_to_speech_save(response_data['answer_en'], audio_path)
                
                # Add audio URL to response
                response_data['audio_url'] = f"/audio/{audio_filename}"
            except Exception as e:
                logger.error(f"Error generating TTS: {str(e)}")
                # Continue without audio if TTS fails
                response_data['audio_url'] = None
        
        return jsonify(response_data)
    
    except ValueError as e:
        return jsonify({"error": str(e)}), 500
    except Exception as e:
        logger.exception("Unexpected error in /api/chat endpoint")
        return jsonify({"error": "Internal server error"}), 500


@app.route('/api/tts', methods=['POST'])
def tts():
    """
    Generate TTS audio from text
    """
    try:
        data = request.json
        if not data or 'text' not in data:
            return jsonify({"error": "Missing 'text' in request"}), 400
        
        text = data.get('text', '').strip()
        voice = data.get('voice', 'en-US-Wavenet-A')  # Default voice
        
        if not text:
            return jsonify({"error": "Empty text"}), 400
        
        # Generate a unique filename
        audio_filename = f"{uuid.uuid4()}.mp3"
        audio_path = os.path.join(AUDIO_TMP_DIR, audio_filename)
        
        # Generate audio file
        text_to_speech_save(text, audio_path, voice=voice)
        
        return jsonify({"audio_url": f"/audio/{audio_filename}"})
    
    except Exception as e:
        logger.exception("Unexpected error in /api/tts endpoint")
        return jsonify({"error": "Internal server error"}), 500


@app.route('/audio/<filename>')
def serve_audio(filename):
    """
    Serve generated audio files
    """
    return send_from_directory(AUDIO_TMP_DIR, filename)


@app.route('/api/history', methods=['GET'])
def get_history():
    """
    Get chat history (placeholder - implement based on your storage strategy)
    """
    # This is a placeholder. In a real implementation, you would:
    # 1. Get user ID from session/token
    # 2. Retrieve chat history from database/cache
    # 3. Return formatted history
    
    # For now, return empty history
    return jsonify({"history": []})


if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=os.getenv('FLASK_ENV') == 'development')