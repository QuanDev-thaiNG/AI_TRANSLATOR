import os
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Try to import gTTS, but don't fail if it's not installed
try:
    from gtts import gTTS
    GTTS_AVAILABLE = True
except ImportError:
    logger.warning("gTTS not available. Install with 'pip install gtts' for server-side TTS.")
    GTTS_AVAILABLE = False

# Try to import pyttsx3, but don't fail if it's not installed
try:
    import pyttsx3
    PYTTSX3_AVAILABLE = True
except ImportError:
    logger.warning("pyttsx3 not available. Install with 'pip install pyttsx3' for offline TTS.")
    PYTTSX3_AVAILABLE = False


def text_to_speech_save(text: str, output_path: str, voice: Optional[str] = None) -> bool:
    """
    Convert text to speech and save to file
    
    Args:
        text: Text to convert to speech
        output_path: Path to save audio file
        voice: Voice ID (only used for some TTS providers)
        
    Returns:
        bool: True if successful, False otherwise
    """
    # Create directory if it doesn't exist
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # Try gTTS first (online, better quality)
    if GTTS_AVAILABLE:
        try:
            tts = gTTS(text=text, lang='en', slow=False)
            tts.save(output_path)
            logger.debug(f"Generated TTS with gTTS: {output_path}")
            return True
        except Exception as e:
            logger.warning(f"gTTS failed: {str(e)}. Falling back to pyttsx3 if available.")
    
    # Fall back to pyttsx3 (offline, lower quality)
    if PYTTSX3_AVAILABLE:
        try:
            engine = pyttsx3.init()
            # Set voice if provided
            if voice:
                voices = engine.getProperty('voices')
                for v in voices:
                    if voice in v.id:  # Simple partial match
                        engine.setProperty('voice', v.id)
                        break
            
            # Set properties
            engine.setProperty('rate', 150)  # Speed
            engine.setProperty('volume', 0.9)  # Volume (0.0 to 1.0)
            
            # Save to file
            engine.save_to_file(text, output_path)
            engine.runAndWait()
            logger.debug(f"Generated TTS with pyttsx3: {output_path}")
            return True
        except Exception as e:
            logger.error(f"pyttsx3 TTS failed: {str(e)}")
    
    logger.error("No TTS engine available. Install gTTS or pyttsx3.")
    return False


# Example of how to use Google Cloud TTS (if credentials are set up)
def google_cloud_tts(text: str, output_path: str, voice_name: str = 'en-US-Wavenet-D') -> bool:
    """
    Use Google Cloud Text-to-Speech API to generate audio
    Requires: pip install google-cloud-texttospeech
    
    Args:
        text: Text to convert to speech
        output_path: Path to save audio file
        voice_name: Google Cloud TTS voice name
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        from google.cloud import texttospeech
        
        # Initialize client
        client = texttospeech.TextToSpeechClient()
        
        # Set input text
        synthesis_input = texttospeech.SynthesisInput(text=text)
        
        # Build voice request
        voice = texttospeech.VoiceSelectionParams(
            language_code="en-US",
            name=voice_name,
            ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL
        )
        
        # Select audio config
        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MP3
        )
        
        # Perform text-to-speech request
        response = client.synthesize_speech(
            input=synthesis_input, voice=voice, audio_config=audio_config
        )
        
        # Write response to output file
        with open(output_path, "wb") as out:
            out.write(response.audio_content)
        
        logger.debug(f"Generated TTS with Google Cloud: {output_path}")
        return True
    
    except ImportError:
        logger.warning("Google Cloud TTS not available. Install with 'pip install google-cloud-texttospeech'")
        return False
    except Exception as e:
        logger.error(f"Google Cloud TTS failed: {str(e)}")
        return False


# Example of how to implement client-side TTS with Web Speech API
def get_web_speech_api_script() -> str:
    """
    Return JavaScript code for client-side TTS using Web Speech API
    
    Returns:
        str: JavaScript code for Web Speech API TTS
    """
    return """
    function speakText(text) {
        // Check if browser supports speech synthesis
        if ('speechSynthesis' in window) {
            // Create a new speech synthesis utterance
            const utterance = new SpeechSynthesisUtterance(text);
            
            // Set properties
            utterance.lang = 'en-US';
            utterance.rate = 1.0;  // 0.1 to 10
            utterance.pitch = 1.0; // 0 to 2
            utterance.volume = 1.0; // 0 to 1
            
            // Optional: Select a voice
            window.speechSynthesis.onvoiceschanged = () => {
                const voices = window.speechSynthesis.getVoices();
                // Find a good English voice
                const englishVoices = voices.filter(voice => voice.lang.includes('en-'));
                if (englishVoices.length > 0) {
                    utterance.voice = englishVoices[0];
                }
            };
            
            // Speak the text
            window.speechSynthesis.speak(utterance);
            return true;
        } else {
            console.error('Speech synthesis not supported in this browser');
            return false;
        }
    }
    """