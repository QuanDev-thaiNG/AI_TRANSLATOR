import os
import json
import logging
import requests
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

# System prompt for Gemini API
SYSTEM_PROMPT = """
You are an English language tutor helping non-native speakers practice English conversation.
For each user message, provide:
1. A natural, helpful response in English (answer_en)
2. A Vietnamese translation of your response (translation_vi)
3. A Simplified Chinese translation of your response with Pinyin (translation_zh)
4. Grammar analysis of any errors or improvements in the user's message (grammar_notes)

Your response MUST be in the following JSON format:
{
  "answer_en": "Your English response here",
  "translation_vi": "Vietnamese translation of your response",
  "translation_zh": "简体中文翻译 (pīnyīn)",
  "grammar_notes": {
    "summary": "Brief summary of grammar points",
    "issues": [
      {
        "text": "Problematic text from user",
        "correction": "Corrected version",
        "explanation": "Explanation of the grammar rule"
      }
    ],
    "vocabulary_suggestions": ["alternative1", "alternative2"]
  }
}
"""


class GeminiProvider:
    """
    Provider for Gemini API integration
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize Gemini provider
        
        Args:
            api_key: Gemini API key (defaults to GEMINI_API_KEY env var)
        """
        self.api_key = api_key or os.getenv('GEMINI_API_KEY')
        if not self.api_key:
            logger.warning("GEMINI_API_KEY not set. Provider will not work without an API key.")
    
    def send_prompt(self, prompt: str, temperature: float = 0.7) -> Dict[str, Any]:
        """
        Send prompt to Gemini API and return structured response
        
        Args:
            prompt: User prompt text
            temperature: Sampling temperature (0.0 to 1.0)
            
        Returns:
            Dict with answer_en, translation_vi, and grammar_notes
            
        Raises:
            ValueError: If API key is not configured
            requests.exceptions.RequestException: For API call failures
        """
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY not configured")
        
        try:
            # Gemini API endpoint
            url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
            
            # Prepare request payload
            payload = {
                "contents": [
                    {
                        "role": "user",
                        "parts": [{"text": SYSTEM_PROMPT + "\n\nUser message: " + prompt}]
                    }
                ],
                "generationConfig": {
                    "temperature": temperature,
                    "topK": 40,
                    "topP": 0.95,
                    "maxOutputTokens": 1024
                }
            }
            
            # Send request to Gemini API
            headers = {
                "Content-Type": "application/json",
                "x-goog-api-key": self.api_key
            }
            
            response = requests.post(url, headers=headers, json=payload)
            response.raise_for_status()  # Raise exception for HTTP errors
            
            # Parse response
            result = response.json()
            
            # Extract text from response
            response_text = result.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '')
            
            # Parse JSON from response text
            try:
                response_data = json.loads(response_text)
                # Validate response structure
                return self._validate_response(response_data)
            except json.JSONDecodeError:
                logger.error(f"Failed to parse JSON from Gemini response: {response_text}")
                # Return fallback response
                return self._get_fallback_response()
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Error calling Gemini API: {str(e)}")
            raise
    
    def _validate_response(self, response_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate and normalize response structure
        
        Args:
            response_data: Raw response data from API
            
        Returns:
            Normalized response data
        """
        # Check required fields
        required_fields = ['answer_en', 'translation_vi', 'grammar_notes']
        for field in required_fields:
            if field not in response_data:
                logger.warning(f"Field {field} missing in Gemini response")
                response_data[field] = "" if field != "grammar_notes" else {"summary": "", "issues": [], "vocabulary_suggestions": []}
        
        # Ensure grammar_notes has the correct structure
        if 'grammar_notes' in response_data and isinstance(response_data['grammar_notes'], dict):
            grammar_fields = ['summary', 'issues', 'vocabulary_suggestions']
            for field in grammar_fields:
                if field not in response_data['grammar_notes']:
                    response_data['grammar_notes'][field] = [] if field != "summary" else ""
        
        return response_data
    
    def _get_fallback_response(self) -> Dict[str, Any]:
        """
        Get fallback response for when API call fails
        
        Returns:
            Default response structure
        """
        return {
            "answer_en": "I'm sorry, I couldn't process your request properly. Could you try again?",
            "translation_vi": "Xin lỗi, tôi không thể xử lý yêu cầu của bạn đúng cách. Bạn có thể thử lại không?",
            "grammar_notes": {
                "summary": "",
                "issues": [],
                "vocabulary_suggestions": []
            }
        }


# Factory function to get the appropriate LLM provider
def get_llm_provider() -> GeminiProvider:
    """
    Get configured LLM provider instance
    
    Returns:
        LLM provider instance
    """
    # Currently only supporting Gemini, but could be extended to support other providers
    return GeminiProvider()


# Convenience function for direct use
def send_prompt_to_llm(prompt: str) -> Dict[str, Any]:
    """
    Send prompt to LLM and get response
    
    Args:
        prompt: User prompt text
        
    Returns:
        Dict with answer_en, translation_vi, and grammar_notes
    """
    provider = get_llm_provider()
    return provider.send_prompt(prompt)